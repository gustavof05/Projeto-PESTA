% Simula��o de circuitos el�ctricos de pot�ncia
% Conversores AC/DC, ponte_conv_motorDC_plot.m

close;

subplot(6,1,1);
plot(y(:,1),y(:,2))
grid
ylabel('Vs (V)');
subplot(6,1,2);
plot(y(:,1),y(:,3))
grid
ylabel('Ith1 (A)');
subplot(6,1,3);
plot(y(:,1),y(:,4))
grid
ylabel('Vth1 (V)');
subplot(6,1,4);
plot(y(:,1),y(:,5))
grid
ylabel('IL (A)');
subplot(6,1,5);
plot(y(:,1),y(:,6))
grid
ylabel('VL (V)');
subplot(6,1,6);
plot(y(:,1),y(:,7))
grid
ylabel('w (rad/s)');
xlabel('Tempo (s)')
