% Simula��o de circuitos el�ctricos de pot�ncia
% Conversores AC/DC, tiristor_plot.m 

close;

subplot(5,1,1);
plot(y(:,1),y(:,2))
grid
ylabel('Vs (V)');
subplot(5,1,2);
plot(y(:,1),y(:,3))
grid
ylabel('Ith1 (A)');
subplot(5,1,3);
plot(y(:,1),y(:,4))
grid
ylabel('Vth1 (V)');
subplot(5,1,4);
plot(y(:,1),y(:,5))
grid
ylabel('IL (A)');
subplot(5,1,5);
plot(y(:,1),y(:,6))
grid
ylabel('VL (V)');
xlabel('Tempo (s)')
