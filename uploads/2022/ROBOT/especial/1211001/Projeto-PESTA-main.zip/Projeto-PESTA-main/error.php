<html lang="pt">
  <head>
    <title>Submiss&atilde;o de relat&oacute;rios</title>
  </head>
  <body>
    <br>
    <br>
    <br>
    <div style="text-align:center"><h1>Ocorreu algum erro com os dados de login</h1></div>
    <br>
    <br>
    <br>
    <form action="login.php" method="POST">
      <div style="text-align:center"><input type="submit" name="login" value="Voltar atrás"/></div>
    </form>
  </body>
</html>
