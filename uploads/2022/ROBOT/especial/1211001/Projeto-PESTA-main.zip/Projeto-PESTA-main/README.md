# Projeto PESTA
 
    No âmbito da cadeira 'PESTA', na Licenciatura em Engenharia Eletrotécnica e de Computadores no ISEP, decidi realizar um projeto em PHP e HTML.
    Inicialmente, a ideia do projeto é fazer uma página PHP de submissão de relatórios com permissões especiais para administradores e uma página HTML onde vão ser expostos alguns dos relatórios dos alunos, escolhidos pelos administradores.